package com.stock.stockify.domain.permission;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/user-roles")
@RequiredArgsConstructor
public class UserRoleController {

    private final UserRoleService userRoleService;

    // 특정 사용자에게 역할을 부여
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> assignRoleToUser(@RequestParam Long userId,
                                                 @RequestParam Long roleId,
                                                 @RequestParam Long warehouseId) {
        userRoleService.assignRoleToUser(userId, roleId, warehouseId);
        return ResponseEntity.ok().build();
    }
}
