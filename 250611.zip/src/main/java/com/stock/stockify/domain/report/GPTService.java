package com.stock.stockify.domain.report;

public interface GPTService {
    String callChatGPT(String prompt);
}