package com.stock.stockify.domain.user;

public class UsernameUpdateRequest {
    private String newUsername;
}