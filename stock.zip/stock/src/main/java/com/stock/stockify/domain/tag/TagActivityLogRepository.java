package com.stock.stockify.domain.tag;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TagActivityLogRepository extends JpaRepository<TagActivityLog, Long> {
}
