package com.stock.stockify.domain.user;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class EmailVerificationService {

    private final EmailVerificationTokenRepository tokenRepository;
    private final UserRepository userRepository;

    // 토큰 생성 및 저장
    @Transactional
    public EmailVerificationToken generateToken(Long userId, String ipAddress, String purpose, long minutesUntilExpire) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("사용자를 찾을 수 없습니다."));

        // 기존 인증되지 않은 동일 purpose 토큰 제거 (중복 인증 방지)
        tokenRepository.findByUserIdAndPurposeAndVerifiedFalse(userId, purpose)
                .ifPresent(tokenRepository::delete);

        EmailVerificationToken token = EmailVerificationToken.builder()
                .user(user)
                .token(UUID.randomUUID().toString())
                .purpose(purpose)
                .expiresAt(LocalDateTime.now().plusMinutes(minutesUntilExpire))
                .ipAddress(ipAddress)
                .build();

        return tokenRepository.save(token);
    }

    // 인증 처리 (링크 클릭 시 호출)
    @Transactional
    public void verifyToken(String tokenString) {
        EmailVerificationToken token = tokenRepository.findByToken(tokenString)
                .orElseThrow(() -> new IllegalArgumentException("유효하지 않은 토큰입니다."));

        if (token.isVerified()) {
            throw new IllegalStateException("이미 인증이 완료된 토큰입니다.");
        }

        if (token.getExpiresAt().isBefore(LocalDateTime.now())) {
            throw new IllegalStateException("토큰이 만료되었습니다.");
        }

        token.setVerified(true);
        token.setVerifiedAt(LocalDateTime.now());

        // 사용자의 email_verified = true 로 설정
        User user = token.getUser();
        user.setEmailVerified(true);
    }
}
