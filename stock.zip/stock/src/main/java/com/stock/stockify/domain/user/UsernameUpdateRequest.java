package com.stock.stockify.domain.user;

import lombok.Getter;


@Getter
public class UsernameUpdateRequest {
    private String newUsername;
}