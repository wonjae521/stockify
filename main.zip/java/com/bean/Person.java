package com.bean;

public class Person {
private String name;
private int age;

public Person() {}
public String getName() {
	return name;
	}

public String setName(String nam) {
	name = nam;
	return name;
	}

public int setAge(int num) {
	age = num;
	return age;
	}
}
