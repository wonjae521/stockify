package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/area")
public class AreaServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public AreaServlet1() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8"); // 한글 입력 처리
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		try {
			// 파라미터 받기
			String w = request.getParameter("width");
			String h = request.getParameter("height");
			
			double width = Double.parseDouble(w);
			double height = Double.parseDouble(h);
			double area = width * height;
			
			out.println("<html><body>");
			out.println("<h2>면적 계산 결과</h2>");
			out.println("가로: " + width + "<br>");
			out.println("세로: " + height + "<br>");
			out.println("<strong>면적: " + area + "</strong>");
			out.println("</body></html>");
		} catch (NumberFormatException e) {
			out.println("<html><body>");
			out.println("<h2>잘못된 입력입니다. 숫자를 입력해주세요.</h2>");
			out.println("</body></html>");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}
}