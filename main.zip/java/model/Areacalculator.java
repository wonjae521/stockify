package model;

public class Areacalculator {
	public static double calculate(double width, double height) {
		return width * height;
	}
}