package model;

import java.sql.*;

public class UserDAO {
	private Connection conn;
	private PreparedStatement pstmt;
	
	public UserDAO() {
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mariadb://localhost:3306/jsp2025", "jsp2025", "password");
		} catch (Exception e) {
			System.out.println("DB 오류 발생: " + e.getMessage());
			e.printStackTrace();
		}
	}
	
	public int insertUser(UserDTO user) {
		int result = 0;
		try {
			String sql = "INSERT INTO users (username, password) VALUES (?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user.getUsername());
			pstmt.setString(2, user.getPassword());
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("DB 오류 발생: " + e.getMessage());
			e.printStackTrace();
		}
		return result;
	}
	
	public boolean login(String username, String password) {
	    boolean isLogin = false;
	    try {
	        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
	        pstmt = conn.prepareStatement(sql);
	        pstmt.setString(1, username);
	        pstmt.setString(2, password);
	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	            isLogin = true;
	        }
	        rs.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return isLogin;
	}
}