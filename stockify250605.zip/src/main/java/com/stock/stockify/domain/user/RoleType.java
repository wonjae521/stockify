package com.stock.stockify.domain.user;

public enum RoleType {
    ADMIN,
    SUBADMIN,
    STAFF
}