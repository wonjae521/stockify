package com.stock.stockify.domain.permission;

import lombok.Getter;
import lombok.Setter;

// 창고 권한
@Getter
@Setter
public class WarehousePermissionRequest {
    private Long warehouseId;
    private boolean canManageInventory; // 재고 관리
    private boolean canManageOrders; // 주문 관리
    private boolean canViewReports; // 보고서 확인
}
