package com.stock.stockify.domain.user;

public enum UserRole {
    ADMIN, // 관리자
    SUBADMIN, // 보조 관리자
    STAFF // 일반 직원
}
