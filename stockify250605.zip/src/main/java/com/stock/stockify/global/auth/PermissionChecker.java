package com.stock.stockify.global.auth;

import com.stock.stockify.domain.user.Permission;
import com.stock.stockify.domain.user.RoleType;
import com.stock.stockify.domain.user.User;
import com.stock.stockify.domain.warehouse.UserWarehouseRole;
import com.stock.stockify.domain.warehouse.UserWarehouseRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.Set;

@Service
public class PermissionChecker {

    private final UserWarehouseRoleRepository warehouseRoleRepository;

    @Autowired
    public PermissionChecker(UserWarehouseRoleRepository warehouseRoleRepository) {
        this.warehouseRoleRepository = warehouseRoleRepository;
    }

    // 최상위 역할 기준으로 글로벌 권한 검사 ex) 관리자 페이지, 시스템 설정 등 창고에 독립적인 작업 시 사용
    public boolean hasGlobalPermission(User user, Permission permission) {
        if (user.getRoleType() == RoleType.ADMIN) return true;

        return switch (user.getRoleType()) {
            case SUBADMIN -> Set.of(
                    Permission.INVENTORY_READ, Permission.INVENTORY_WRITE,
                    Permission.ORDER_MANAGE, Permission.REPORT_VIEW
            ).contains(permission);

            case STAFF -> Set.of(
                    Permission.INVENTORY_READ, Permission.REPORT_VIEW
            ).contains(permission);

            default -> false;
        };
    }

    // 특정 창고에 대해 권한 가지고 있는지 검사, 창고별 역할 다른 경우 사용
    public boolean hasWarehousePermission(User user, Long warehouseId, Permission permission) {
        if (user.getRoleType() == RoleType.ADMIN) return true;

        Optional<UserWarehouseRole> uwr = warehouseRoleRepository
                .findByUserIdAndWarehouseId(user.getId(), warehouseId);

        return uwr.map(role -> hasRoleTypePermission(role.getWarehouseRole(), permission))
                .orElse(false);
    }

    // 주어진 RoleType(SUBADMIN/STAFF)이 해당 권한을 가졌는지 확인
    private boolean hasRoleTypePermission(RoleType role, Permission permission) {
        return switch (role) {
            case SUBADMIN -> Set.of(
                    Permission.INVENTORY_READ, Permission.INVENTORY_WRITE,
                    Permission.ORDER_MANAGE, Permission.REPORT_VIEW
            ).contains(permission);

            case STAFF -> Set.of(
                    Permission.INVENTORY_READ, Permission.REPORT_VIEW
            ).contains(permission);

            default -> false;
        };
    }
}
