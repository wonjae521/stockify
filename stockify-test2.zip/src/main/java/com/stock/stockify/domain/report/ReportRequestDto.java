package com.stock.stockify.domain.report;

import com.stock.stockify.domain.report.ReportType;

public class ReportRequestDto {
    private ReportType type;
    private Long warehouseId;
    private String periodStart;
    private String periodEnd;

    // Getter/Setter 생략
}