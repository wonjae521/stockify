package com.stock.stockify.domain.report;

import java.util.Map;

public class ReportResponseDto {
    private String summary;
    private Map<String, Object> chartData;
    private String rawGptMessage;

    // Getter/Setter 생략
}