package com.stock.stockify.domain.inventory;

public enum Action {
    INBOUND, // 입고
    OUTBOUND, // 출고
    ADJUSTMENT // 조정
}
