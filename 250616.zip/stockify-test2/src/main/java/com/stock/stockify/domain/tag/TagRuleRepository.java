package com.stock.stockify.domain.tag;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TagRuleRepository extends JpaRepository<TagRule, Long> {
}
